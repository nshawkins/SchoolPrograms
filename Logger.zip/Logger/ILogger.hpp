//
//  ILogger.h
//  LoggingTest
//
//  Created by Nordstrom, Steve (Faculty - nordstrosg) on 9/5/19.
//  Copyright © 2019 Nordstrom, Steve (Faculty - nordstrosg). All rights reserved.
//

#ifndef ILogger_hpp
#define ILogger_hpp

class ILogger { 
public:
    
    
    // virtual destructor (critical for deleting derived classed via a base class pointer).
    virtual ~ILogger() {} ;
    
    // pure virtual functions follow here to ensure class can not be instantiated directly, needs to be specialized/derived.
    
    /// <summary>
    /// Method to log some string data
    /// </summary>
    /// <param name="line">A string to put as a line of text in the log</param>
    /// <returns>True if line was logged properly, false otherwise</returns>
    virtual bool Log(std::string line) = 0;
    
    /// <summary>
    /// Control method to turn on file-based logging
    /// </summary>
    virtual void EnableFileLogging() = 0;
    
    /// <summary>
    /// Control method to turn off file-based logging
    /// </summary>
    virtual void DisableFileLogging() = 0;
    
    /// <summary>
    /// Control method to turn on console-based logging
    /// </summary>
    virtual void EnableConsoleLogging() = 0;
    
    /// <summary>
    /// Control method to turn off console-based logging
    /// </summary>
    virtual void DisableConsoleLogging() = 0;
    
    /// <summary>
    /// String property to view details of the implementation
    /// </summary>
    virtual std::string GetInfo() = 0;
    
    /// <summary>
    /// Boolean property which reflects if the log is currently logging to a file
    /// </summary>
    virtual bool IsFileLogEnabled() = 0;
    
    /// <summary>
    /// Boolean property which reflects if the log is currently logging to the console
    /// </summary>
    virtual bool IsConsoleLogEnabled() = 0;
    
protected:
    std::string info;
    bool fileLogEnabled;
    bool consoleLogEnabled;

};

#endif /* ILogger_hpp */
