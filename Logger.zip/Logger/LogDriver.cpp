//
//  main.cpp
//  LoggingTest
//
//  Created by Nordstrom, Steve (Faculty - nordstrosg) on 9/5/19.
//  Copyright © 2019 Nordstrom, Steve (Faculty - nordstrosg). All rights reserved.
//

#include <iostream>

#include "Logger.hpp"

int main() {
    
    //ILogger *myLogger = new Logger();

    //myLogger->DisableConsoleLogging();
    
    // Instantiate a class which provides ILogger functionality...
    ILogger *logger = new Logger("test.txt");
    
    // Use this line to test an alternate way of instantiating a Logger
    //ILogger logger = new Logger();
    
    logger->Log("Test... 1, 2, 3...");
    
    logger->EnableFileLogging();
    logger->Log("Test... 4, 5, 6...");
    
    logger->DisableFileLogging();
    logger->Log("You should not see this line in the file!");
    
    logger->DisableConsoleLogging();
    logger->Log("You should not see this line at all!");
    
    logger->EnableConsoleLogging();
    logger->Log("You should not see this line in the file either.");
    
    logger->EnableFileLogging();
    logger->Log("This should not be the only line in your log file!");
    
    logger->DisableConsoleLogging();
    logger->Log("You should only see this line in the file!");
    logger->EnableConsoleLogging();
    logger->Log("You should see this line in both.");
    
    delete logger;
    
    return 0;
}
