
/*
#include <iostream>
#include <string>

#include "LStack.cpp"
#include <fstream>


int main() {
	//how to use generic programming in c++
	//std::ofstream input;
	//input.open("InfixExpressions.txt");

	LStack<int> mystack;
	int five = 5;
	int six = 6;
	int seven = 7;
	int eight = 8;

	mystack.Push(five);
	mystack.Push(six);
	mystack.Push(seven);
	mystack.Push(eight);
	mystack.Push(five);
	mystack.Push(six);
	mystack.Push(seven);
	mystack.Push(eight);
	mystack.Push(five);
	//stack must dynamically resize
	mystack.Push(six);
	mystack.Push(seven);
	mystack.Push(eight);
	mystack.Push(five);
	mystack.Push(six);
	mystack.Push(seven);
	mystack.Push(eight);
	mystack.Push(five);
	mystack.Push(six);
	mystack.Push(seven);
	mystack.Push(eight);

	mystack.IsEmpty();
	mystack.Pop();
	mystack.Top();

	mystack.PrettyPrint();

	std::cout << std::endl << "-------------------------" << std::endl;

	LStack<std::string> stringstack;
	std::string exp = "a+b*(c^d-e)^(f+g*h)-i";
	stringstack.Push(exp);
	stringstack.infixToPostfix(exp);
	
	stringstack.PrettyPrint();
}*/