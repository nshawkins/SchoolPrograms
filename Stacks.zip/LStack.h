#pragma once
#define LStack_hpp

#include <stdio.h>
#include <string>

template <class T>
class LStack {
private:
	//dynamically allocate array
	T *parr; //p for pointer, arr being pointed to
	size_t top;
	size_t arraySize;

public:
	LStack();
	void Initialize();
	//possibly lowercase all 
	void Push(T& item);
	T Pop();
	void Clear();
	T Top();
	T PrettyPrint();
	bool IsEmpty();
	T infixToPostfix(T s);
	//many more
};