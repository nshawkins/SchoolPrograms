#include <iostream>
#include <string>

#include "LStack.cpp"
#include <fstream>

int main() {
	//how to use generic programming in c++
	std::ofstream input;

	input.open("InfixExpressions.txt");
	LStack<int> mystack;
	int five = 5;
	int six = 6;
	int seven = 7;
	int eight = 8;
	LStack<std::string> filestack;
	std::string infix = "4+5";

	filestack.Push(infix);
	//filestack.PostFix(infix);

	mystack.Push(five);
	mystack.Push(six);
	mystack.Push(seven);
	mystack.Push(eight);

	mystack.IsEmpty();
	mystack.Pop();
	mystack.Top();
	mystack.PrettyPrint();
}