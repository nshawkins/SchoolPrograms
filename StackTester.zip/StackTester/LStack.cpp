
#include "LStack.h"
#include <string>

//constructor
template <class T> 
LStack<T>::LStack() {
	//set an initial array size
	arraySize = 10;

	parr = new T[arraySize];
	top = 0;
}

template <class T>
void LStack<T>::Initialize() {
	//do stuff similar to what constructor did
	//release any existing array?

	delete parr;

	//make new array
	parr = new T[arraySize];
	//reset top to 0
	top = 0;
}

template <class T>
void LStack<T>::Push(T& item) { //T(reference) item
	if (top < arraySize) {
		parr[top++] = item;//post incrementation 
		//top++;^
	}
	else {
		// allocate more space
		T *tmpArray = new T[arraySize * 2];

		if (tmpArray != NULL) {
			arraySize *= 2;
		

		//copy all of old array in parr into tmpArray
		for (int i = 0; i < arraySize; i++) {
			//make assumptions here...
			tmpArray[i] = parr[i]; //hopefully this works
		}
		//delete old array
		delete[] parr;

		parr = tmpArray;

		//now put it in the thing like before
		parr[top++] = item;
		}

	}
}

template <class T>
T LStack<T>::Pop() {
	//make sure array is not empty first
	if (top > 0) {
		return parr[--top];
	}
}

template <class T>
T LStack<T>::Top() {
	if (top > 0) {
		return parr[top - 1];
	}
}

template <class T>
bool LStack<T>::IsEmpty() {
	if (top == 0) {
		return true;
	}
	else {
		return false;
	}
}

template <class T>
void LStack<T>::Clear() {
	for (int i = 0; i <= arraySize; i++) {
		parr[i] = 0;
	}
}

template <class T>
T LStack<T>::PrettyPrint() {
	for (int i = 0; i <= arraySize; i++) {
		std::cout << parr[i];
	}
	return true;
}

/*
template <class T>
T LStack<T>::PostFix(T input) {
	int prec(char c){
	syntax error : unexpected token 'int', expected 'declaration'	101

		if (c == '^')
			return 3;
		else if (c == '*' || c == '/')
			return 2;
		else if (c == '+' || c == '-')
			return 1;
		else
			return -1;
	}
	void infixToPostfix(string s){
		syntax error : unexpected token 'identifier', expected ')'	113

		std::LStack<char> st;
		st.Push('N');
		int l = s.length();
		string ns;
		for (int i = 0; i < l; i++){
			// If the scanned character is an operand, add it to output string. 
			if ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z'))
				ns += s[i];

			// If the scanned character is an �(�, push it to the stack. 
			else if (s[i] == '(')

				st.Push('(');

			// If the scanned character is an �)�, pop and to output string from the stack 
			// until an �(� is encountered. 
			else if (s[i] == ')')
			{
				while (st.Top() != 'N' && st.Top() != '('){
					char c = st.Top();
					st.Pop();
					ns += c;
				}
				if (st.Top() == '('){
					char c = st.Top();
					st.Pop();
				}
			}

			//If an operator is scanned 
			else {
				while (st.Top() != 'N' && prec(s[i]) <= prec(st.Top())){
					char c = st.Top();
					st.Pop();
					ns += c;
				}
				st.Push(s[i]);
			}

		}
		//Pop all the remaining elements from the stack 
		while (st.Top() != 'N'){
			char c = st.Top();
			st.Pop();
			ns += c;
		}

		cout << ns << endl;

	}
}*/

/*
template <class T>
int Evaluate(char exp) {
	// Scan all characters one by one  
	for (int i = 0; exp[i]; ++i){
		// If the scanned character is an operand (number here),  
		// push it to the stack.  
		if (isdigit(exp[i])) {
			//LStack.Push(exp[i] - '0');
			//syntax error : unexpected token '.', expected 'declaration'	180

		}

		// If the scanned character is an operator, pop two  
		// elements from stack apply the operator  
		else{
			int val1 = LStack.Pop();
			int val2 = LStack.Pop();
			switch (exp[i]){
			case '+': LStack.Push(val2 + val1); break;
			case '-': LStack.Push(val2 - val1); break;
			case '*': LStack.Push(val2 * val1); break;
			case '/': LStack.Push(val2 / val1); break;
				//syntax error : unexpected token '.', expected 'declaration'
			}
		}
		return LStack<T>.Pop();
	}
}*/