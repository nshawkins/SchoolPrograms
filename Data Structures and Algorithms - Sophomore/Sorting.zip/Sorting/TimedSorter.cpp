#include "TimedSorter.h"
#include <chrono>
#include <utility>
#include <iostream>
#include <algorithm>

using namespace std::chrono;

int k;
int n;
int j;
int i; 
int s; 
int l;
int r;
int temp;
int max;
int comparisons = 0;

template <class T>
TimedSorter<T>::TimedSorter(long timeoutMilliseconds) : timeout(timeoutMilliseconds){

}

template <class T>
void TimedSorter<T>::startTimer(){
	startTime = std::chrono::steady_clock::now();
	//auto start = high_resolution_clock::now();
}

template <class T>
void TimedSorter<T>::checkpointTimer(){

	currentTime = std::chrono::steady_clock::now();
	deltaT = currentTime - startTime;
}

template <class T>
bool TimedSorter<T>::timeExpired(long timeoutMilliseconds){

	return std::chrono::duration_cast<std::chrono::milliseconds>(deltaT).count() > timeoutMilliseconds;

}

template <class T>
long TimedSorter<T>::timeInMilliseconds(){

	return std::chrono::duration_cast<std::chrono::milliseconds>(deltaT).count();

}

template <typename T>
bool TimedSorter<T>::Timeout(long comparisons) {
	if (comparisons < 100) {
		return false;
	}
	else {
		return true;
	}
}
template <class T>
long TimedSorter<T>::BubbleSort(T* array, size_t arraySize){

	//startTimer();

	long comparisons = 0;

	for (size_t i = 0; i < arraySize - 1; i++){

		//checkpointTimer();
		std::cout << "Bubble" << std::endl;
		/*if (timeExpired(timeout)){
			return -1;
		} 
		if (Timeout(comparisons) == true) {
			return -1;
		} */

		for (size_t j = 0; j < arraySize - i - 1; j++){
			comparisons++;

			if (array[j] > array[j + 1]){
				std::swap(array[j], array[j + 1]);
			}

		}
	}
	//long endTime = timeInMilliseconds();
	return comparisons;
}

//pivot for quick sort

template <typename T>
int TimedSorter<T>::partition(T A[], int l, int r) {
	//choose pivot value

	T pivot = A[l];
	int left = l;
	int right = r;
	while (left < right) {
		while (A[right] > pivot) right--;
		while (left < right && A[left] <= pivot) left++;
		if (left < right) {
			std::swap(A[left], A[right]);
		}
	}
	std::swap(A[l], A[right]);
	return right; //index of pivot
}

//quicksort using pivot
template <typename T>
long TimedSorter<T>::QuickSort(T A[], int l, int r) {//T* array, size_t arraySize

	//startTimer();
	//long comparisons = 0;
	std::cout << "Quick" << std::endl;
	if (l < r) {
		comparisons++;
		/*
		if (Timeout(comparisons) == true) {
			return -1;
		} */
		int pivotIndex = partition(A, l, r);
		QuickSort(A, l, (pivotIndex - 1));
		QuickSort(A, (pivotIndex + 1), r);
	}
	//long endTime = timeInMilliseconds();
	return comparisons;
} 

template <typename T>
long TimedSorter<T>::SelectionSort(T * array, size_t arraySize) {
	//startTimer();
	long comparisons = 0;
	int pos = 0;
	for (k = 0; k < arraySize; k++) {
		//checkpointTimer();
		std::cout << "Selection" << std::endl;
		/*if (timeExpired(timeout)){
			return -1;
		} 
		if (Timeout(comparisons) == true) {
			return -1;
		} */
		max = array[i];
		for (i = 0; i < arraySize - 1; i++) {
			comparisons++;
			if (array[i] > max) {
				pos = i;
			}
		}
		std::swap(array[pos], array[arraySize - k]);
	}
	//long endTime = timeInMilliseconds();
	return comparisons;
}


template <typename T>
long TimedSorter<T>::InsertionSort(T* array, size_t arraySize) {
	//startTimer();
	long comparisons = 0;
	for (int i = 1; i < arraySize; i++) {//adjust this
		//checkpointTimer();
		std::cout << "Insertion" << std::endl;
		/*if (timeExpired(timeout)){
			return -1;
		} 
		if (Timeout(comparisons) == true) {
			return -1;
		} */
		for (j = s + 1; j < n - 2; j++) {
			comparisons++;
			temp = array[s];
			if (array[i] < temp) {
				array[i] = array[j + 1];
			}
			else {
				break;
			}
			array[j] = temp;
		}
	}
	//long endTime = timeInMilliseconds();
	return comparisons;
} 

//Merge function is from geeks for geeks
template <typename T>
int TimedSorter<T>::Merge(T A[], int l, int mid, int r) {
	int i, j, k;
	int n1 = mid - l + 1;
	int n2 = r - mid;

	// create temp arrays
	int* L = new int[n1];
	int* R = new int[n2];

	// Copy data to temp arrays L[] and R[] 
	for (i = 0; i < n1; i++) {
		L[i] = A[l + i];
	}
	for (j = 0; j < n2; j++) {
		R[j] = A[mid + 1 + j];
	}

	// Merge the temp arrays back into arr[l..r]
	i = 0; // Initial index of first subarray 
	j = 0; // Initial index of second subarray 
	k = l; // Initial index of merged subarray 
	while (i < n1 && j < n2)
	{
		if (L[i] <= R[j])
		{
			A[k] = L[i];
			i++;
		}
		else
		{
			A[k] = R[j];
			j++;
		}
		k++;
	}

	// Copy the remaining elements of L[], if there are any 
	while (i < n1)
	{
		A[k] = L[i];
		i++;
		k++;
	}

	// Copy the remaining elements of R[], if there are any 
	while (j < n2)
	{
		A[k] = R[j];
		j++;
		k++;
	} 
	return 0;
}

template <typename T>
long TimedSorter<T>::MergeSort(T A[], int l, int r) { //T* array, size_t arraySize
	//find middle
	//startTimer();
	comparisons++;
	//std::cout << "Merge" << std::endl;
	/*if (timeExpired(timeout)){
			return -1;
		} 
	if (Timeout(comparisons) == true) {
		return -1;
	} */
	int mid = (l + r) / 2;
	MergeSort(A, l, mid);
	MergeSort(A, mid + 1, r);
	Merge(A, l, mid, r);
	//long endTime = timeInMilliseconds();
	return comparisons;
}

//shell sort is from geeks for geeks
template <typename T>
long TimedSorter<T>::ShellSort(T array[], size_t arraySize){
	// Start with a big gap, then reduce the gap 
	for (int gap = arraySize / 2; gap > 0; gap /= 2)
	{
		for (int i = gap; i < arraySize; i += 1)
		{
			std::cout << "Shell" << std::endl;
			int temp = array[i];
			int j;
			for (j = i; j >= gap && array[j - gap] > temp; j -= gap) {
				array[j] = array[j - gap];
			}
			array[j] = temp;
		}
	}
	return 0;
}

//getNextGap is from geeks for geeks
int getNextGap(int gap)
{
	// Shrink gap by Shrink factor 
	gap = (gap * 10) / 13;

	if (gap < 1)
		return 1;
	return gap;
}

//comb sort is from geeks for geeks
template <typename T>
long TimedSorter<T>::CombSort(T array[], size_t arraySize){
	// Initialize gap 
	int gap = arraySize;
	bool swapped = true;

	while (gap != 1 || swapped == true){
		// Find next gap 
		std::cout << "Comb" << std::endl;
		gap = getNextGap(gap);
		swapped = false;

		for (int i = 0; i < arraySize - gap; i++){
			if (array[i] > array[i + gap]){
				std::swap(array[i], array[i + gap]);
				swapped = true;
			}
		}
	}
	return 0;
}
// explicit template instantiations
template class TimedSorter<int>;