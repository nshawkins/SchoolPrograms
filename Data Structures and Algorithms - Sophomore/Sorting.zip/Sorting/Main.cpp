#include <iostream>
#include <string>

#include "TimedSorter.h"

int main() {

	TimedSorter<int>* mySorter = new TimedSorter<int>(100);

	size_t arraySize = 2048; // can make this 8 million to hold all array sizes

	int* myArray = new int[arraySize];

	for (int i = 0; i < arraySize; i++) {
		//put random stuff here
		myArray[i] = rand() % arraySize;
	}

	long measurement = mySorter->BubbleSort(myArray, arraySize);
	long measurement1 = mySorter->QuickSort(myArray, 0, arraySize); //works but terminates with heap corruption
	long measurement2 = mySorter->InsertionSort(myArray, arraySize);
	long measurement4 = mySorter->SelectionSort(myArray, arraySize + 1); //works but terminates with heap corruption 
	//long measurement3 = mySorter->MergeSort(myArray, 0, arraySize*2); //has a read access violation somewhere
	long measurement5 = mySorter->ShellSort(myArray, arraySize);
	long measurement6 = mySorter->CombSort(myArray, arraySize);
	
	if (measurement < 0) {
		std::cout << "Timeout! Skipping remaining arrays for BubbleSort" << std::endl;
	}
	else {
		std::cout << "Bubble Done!" << std::endl;
	} 
	
	if (measurement1 < 0) {
		std::cout << "Timeout! Skipping remaining arrays for QuickSort" << std::endl;
	}
	else {
		std::cout << "Quick Done!" << std::endl;
	}
	
	if (measurement2 < 0) {
		std::cout << "Timeout! Skipping remaining arrays for InsertionSort" << std::endl;
	}
	else {
		std::cout << "Insertion Done!" << std::endl;
	} 
	/*
	if (measurement3 < 0) {
		std::cout << "Timeout! Skipping remaining arrays for MergeSort" << std::endl;
	}
	else {
		std::cout << "Merge Done!" << std::endl;
	} */

	if (measurement4 < 0) {
		std::cout << "Timeout! Skipping remaining arrays for SelectionSort" << std::endl;
	}
	else {
		std::cout << "Selection Done!" << std::endl;
	} 
	if (measurement5 < 0) {
		std::cout << "Timeout! Skipping remaining arrays for ShellSort" << std::endl;
	}
	else {
		std::cout << "Shell Done!" << std::endl;
	}
	if (measurement6 < 0) {
		std::cout << "Timeout! Skipping remaining arrays for CombSort" << std::endl;
	}
	else {
		std::cout << "Comb Done!" << std::endl;
	}

	std::cout << "Array Size: " << arraySize << std::endl;

	std::cout << "QuickSort and Selection sort work but once the program terminates,"
		<< " it throws a 'HEAP CORRUPTION' error that i dont know how to fix."
		<< " MergeSort has a read access violation that i dont know how to fix.";

	delete mySorter;
	delete[] myArray;
}