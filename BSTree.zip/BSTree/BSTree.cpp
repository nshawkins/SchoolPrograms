#include "BSTree.h"

//constructor
template <typename T>
BSTree<T>::BSTree() : theTree(nullptr){ //copy constructor semantics

}

//constructor where someone passes in a tree
template <typename T>
BSTree<T>::BSTree(const BSTree<T> &rhs) : theTree(nullptr){
	if (rhs.theTree != nullptr) {
		theTree = new BSTreeNode<T>(*rhs.theTree);
	}
}

//destructor
template <typename T>
BSTree<T>::~BSTree() {
	//what to do here? hmmmmm....
	delete theTree;
}

template <typename T>
bool BSTree<T>::IsEmpty() {
	return (theTree != nullptr);
}

template <typename T>
void BSTree<T>::Print() {
	if (theTree != nullptr) {
		theTree->NodePrint();
	}
}

template <typename T>
void BSTree<T>::Insert(const T &data) {
	if (theTree == nullptr) {
		//the tree is currently empty
		theTree = new BSTreeNode<T>(data); //use constructor of BSTreeNode here
	}
	else {
		theTree->Insert(data);
	}
}

template <typename T>
int BSTree<T>::Max() {
	return theTree->Max();
}

template <typename T>
int BSTree<T>::Size(){ /*https://www.geeksforgeeks.org/write-a-c-program-to-calculate-size-of-a-tree/ */
	return theTree->Size();
}

template <typename T>
void BSTree<T>::PrintDOT() {
	std::cout << "Graph G { " << std::endl << std::endl;
	theTree->PrintDOT();
	std::cout << std::endl << "}";
}

template <typename T>
void BSTree<T>::printPreorder() {
	theTree->printPreorder();
}

template <typename T>
void BSTree<T>::printInorder() {
	theTree->printInorder();
}

template <typename T>
void BSTree<T>::printPostorder() {
	theTree->printPostorder();
}

template <typename T>
void BSTree<T>::Clear() {
	
}

template <typename T>
bool BSTree<T>::Search(T data) {
	return 0;
}

//root of node
template <typename T>
double BSTree<T>::ComputeACE() {
	return theTree->ComputeACE();
}

//explicit templace class instantiation
template class BSTree<int>;
template class BSTree<float>;