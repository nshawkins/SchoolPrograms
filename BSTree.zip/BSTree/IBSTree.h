#pragma once
#include <stddef.h>

template <typename T>
class IBSTree {
public:
	IBSTree() {}; //plain constructor

	IBSTree(const IBSTree<T> &rhs) {}; //copy constructor

	const IBSTree<T> & operator=(const IBSTree<T>& rhs) {}; //assignment opperator

	virtual void Insert(const T& data) = 0;
	virtual bool Search(T data) = 0;
	virtual int Size() = 0;
	virtual void Clear() = 0;
	virtual bool IsEmpty() = 0;

	virtual void Print() = 0; //display elements in: InOrder, PreOrder, or PostOrder see text
	virtual void PrintDOT() = 0; //copy paste this output into graphviz to visualize the tree
	virtual void printPreorder() = 0;
	virtual void printInorder() = 0;
	virtual void printPostorder() = 0;

	virtual int Max() = 0;

	virtual double ComputeACE() = 0; //run to calculate on avg how many comparisons it takes to find an element in current tree

	//destructor 
	virtual ~IBSTree() {};
};
 