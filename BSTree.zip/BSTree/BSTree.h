#pragma once

#define BSTree_hpp
#include <iostream>
#include <stdio.h>
#include "IBSTree.h"
#include "BSTreeNode.h"

template <typename T>
class BSTree : public IBSTree<T> {
private:
	BSTreeNode<T> *theTree; //a.k.a myRoot...
	bool balanceEnabled = false;

public:
	BSTree(); //constructor
	BSTree(const BSTree<T>& rhs); 
	const BSTree<T>& operator=(const BSTree<T>& rhs); //assignment operator
	~BSTree(); //destructor

	void Insert(const T& data);
	bool Search(T data);
	int Size();
	void Clear();
	bool IsEmpty();
	int Max();

	void Print(); //InOrder, PreOrder, PostOrder see text...
	void PrintDOT();
	void printPreorder();
	void printInorder();
	void printPostorder();

	double ComputeACE();
};