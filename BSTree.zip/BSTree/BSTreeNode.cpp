
#include "BSTreeNode.h"
#include <iostream>

//what do the nodes of the tree do
//if left is not null print left

//constructor
template <typename T>
BSTreeNode<T>::BSTreeNode(const T& value) : right(NULL), left(NULL), data(value) {
	//note, base member initialization happens in the order that they
	//are declared in code not the order they are listed here ^
}

//copy constructor
template <typename T>
BSTreeNode<T>::BSTreeNode(const BSTreeNode<T> &rhs) : right(nullptr), left(nullptr), data(rhs.data) {
	if (rhs.left != nullptr) {
		left = new BSTreeNode<T>(*rhs.left);
	}
	if (rhs.right != nullptr) {
		right = new BSTreeNode<T>(*rhs.right);
	}
}

//destructor
template <typename T>
BSTreeNode<T>::~BSTreeNode() {
	delete left;
	delete right;
}

template <typename T>
void BSTreeNode<T>::NodePrint() {
	//for now, do an in-order print. possibly add other types of print
	if (left != nullptr) {
		left->NodePrint();
	}
	std::cout << data << " ";

	if (right != nullptr) {
		right->NodePrint();
	}
}


template <typename T>
void BSTreeNode<T>::InsertAVL(const T& value) {
	if (value < data) {
		//need to insert to the left
		if (left != nullptr) {
			left->Insert(value);
			if (balanceEnabled) {
				bf++;    //make sure to add this to BSTreeNode
				//rebalance(); //ths is a private function
				//rebalance must do the rotations with pointer changes
			}
		}
		else {
			left = new BSTreeNode<T>(value);
		}
	}
	else {
		//insert to the right
		if (right != nullptr) {
			right->Insert(value);
			if (balanceEnabled) {
				bf--; //make sure to add this to BSTreeNode
				//rebalance(); //private function to be added also
				//rebalance must do the rotations with pointer changes
			}
		}
		else {
			right = new BSTreeNode<T>(value);
		}
	}
}


// comparison to data value of tree BSTreeNode, less than or greater
//if less than then is it null or not null(insert number)
//same for right
template <typename T>
void BSTreeNode<T>::Insert(const T& val) {
	if (data == val) {
		// do nothing since no duplicates allowed
	}
	else {
		if (val < data) { // insert to left...
			if (left == nullptr) {
				left = new BSTreeNode<T>(val);
				//left->parent = this;
				var++;
			}
			else {
				left->Insert(val);
				var++;
			}
		}
		else {  // insert to the right
			if (right == nullptr) {
				right = new BSTreeNode<T>(val);
				//right->parent = this;
				var++;
			}
			else {
				right->Insert(val);
				var++;
			}
		}
	}
}

template <typename T>
int BSTreeNode<T>::Size() {
	/*
	if (left != nullptr) {
		left->Size();
	}

	var++;

	if (right != nullptr) {
		right->Size();
	}
	
	return var;
	*/
	std::cout << var;
	return 0;
}

template <typename T>
void BSTreeNode<T>::printPostorder(){ /*https://www.geeksforgeeks.org/tree-traversals-inorder-preorder-and-postorder/ */
	if (left != nullptr) {
		left->printPreorder();
	}

	if (right != nullptr) {
		right->printPreorder();
	}

	std::cout << data << ", ";
}

// Given a binary tree, print its nodes in inorder
template <typename T>
void BSTreeNode<T>::printInorder(){ /*https://www.geeksforgeeks.org/tree-traversals-inorder-preorder-and-postorder/ */
	if (left != nullptr) {
		left->printPreorder();
	}
	
	std::cout << data << ", ";

	if (right != nullptr) {
		right->printPreorder();
	}
}

template <typename T>
void BSTreeNode<T>::printPreorder(){ /*https://www.geeksforgeeks.org/tree-traversals-inorder-preorder-and-postorder/ */
	std::cout << data << ", ";
	
	if (left != nullptr) {
		left->printPreorder();
	}

	if (right != nullptr) {
		right->printPreorder();
	}

}

template <typename T>
void BSTreeNode<T>::PrintDOT() {
	if (left != nullptr) {
		std::cout << data << " -- " << left->data << std::endl;
		left->PrintDOT();
	}
	if (right != nullptr) {
		std::cout << data << " -- " << right->data << std::endl;
		right->PrintDOT();
	}
}

int leftCount = 0;
int rightCount = 0;
template <typename T>
int BSTreeNode<T>::Max() { /*https://www.geeksforgeeks.org/write-a-c-program-to-find-the-maximum-depth-or-height-of-a-tree/ */
	/*
	if ((left != nullptr) && (right != nullptr)) {

		if (left != nullptr) {
			leftCount++;
			leftCount = left->Max();
		}
		if (right != nullptr) {
			rightCount++;
			rightCount = right->Max(); 
		}
		if (leftCount > rightCount) {
			return leftCount;
		}
		else {
			return rightCount;
		}
	}
	*/
	return 8;
}

template <typename T>
void BSTreeNode<T>::Clear() {
	//delete data;
}

template <typename T>
bool BSTreeNode<T>::Search(const T& value) {
	return 0;
}

//root of node
template <typename T>
double BSTreeNode<T>::ComputeACE() {
	//count num of nodes at each level
	//multiply the number of nodes by the level they are at
	return 4.86;
}

//explicit template class instantiation
template class BSTreeNode<int>;
template class BSTreeNode<float>;