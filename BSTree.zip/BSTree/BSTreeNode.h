#pragma once
#define BSTreeNode_hpp

template <typename T>
class BSTreeNode {
private:
	BSTreeNode<T> *right;
	BSTreeNode<T> *left;
	BSTreeNode<T> *parent;
	T data;
	bool balanceEnabled = false;
	int bf = 0;

public:
	BSTreeNode(const T& value); //custom constructor
	BSTreeNode(const BSTreeNode<T> &rhs); //copy constructor
	const BSTreeNode<T> & operator = (const BSTreeNode<T> &rhs); //assignment operator

	~BSTreeNode(); //destructor

	void Insert(const T& value);
	void InsertAVL(const T& value);
	bool Search(const T& value);
	int Size();
	void Clear();
	void NodePrint();
	void PrintDOT();
	void printPreorder();
	void printInorder();
	void printPostorder();
	int Max();

	int var = 1;

	//get set for balanceEnabled here...

	double ComputeACE();

};