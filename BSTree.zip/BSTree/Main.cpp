#include <iostream>
#include "BSTree.h"

int main(int argc, const char* argv[]) {

	IBSTree<int> *floatTree = new BSTree<int>();
	//IBSTree<T> floatTree = new BSTree<T>();
	//BSTree<double> floatTree;

	floatTree->Insert(45);
	floatTree->Insert(87);
	floatTree->Insert(12);
	floatTree->Insert(13);
	floatTree->Insert(11);
	floatTree->Insert(9);
	floatTree->Insert(21);
	floatTree->Insert(34);
	floatTree->Insert(36);
	floatTree->Insert(55);
	floatTree->Insert(18);
	floatTree->Insert(23);
	floatTree->Insert(24);
	floatTree->Insert(7);
	floatTree->Insert(50);
	floatTree->Insert(20);
	floatTree->Insert(2);
	floatTree->Insert(10);
	floatTree->Insert(90);
	floatTree->Insert(86);
	floatTree->Insert(52);
	floatTree->Insert(81);
	floatTree->Insert(22);
	floatTree->Insert(29);
	floatTree->Insert(15);
	floatTree->Insert(6);
	floatTree->Insert(14);
	floatTree->Insert(66);
	floatTree->Insert(77);
	floatTree->Insert(88);

	//researching the program, understanding the program and attemping an apporach took all weekend
	//printDOT, PrintOrder, Max, and Size took 8 hours. 
	//max did not give the correct output
	//i am not sure how to add AVL at all
	//Me, Bennett, Alex, Bryce, and Josh brainstormed together

	floatTree->PrintDOT();
	std::cout << std::endl;
	std::cout << "PreOrdered Print: ";
	floatTree->printPreorder();
	std::cout << std::endl << "InOrdered Print: ";
	floatTree->printInorder();
	std::cout << std::endl << "PostOrdered Print: ";
	floatTree->printPostorder();

	std::cout << std::endl << "Size: ";
	floatTree->Size();
	std::cout << std::endl << "Max: ";
	std::cout << floatTree->Max();
	std::cout << std::endl << "ComputeACE: ";
	std::cout << floatTree->ComputeACE();
	delete floatTree;

	//these should all work
	/*
	IBSTree<float> *otherTree(floatTree);
	IBSTree<float> *anotherTree = otherTree; //rick level stuff
	IBSTree<float> *ptr2Tree = new BSTree<float>((const BSTree<float>&) * anotherTree);

	//ptr2Tree->Print();
	ptr2Tree->PrintDOT();
	std::cout << std::endl;
	std::cout << "PreOrdered Print: ";
	ptr2Tree->printPreorder();
	std::cout << std::endl << "InOrdered Print: ";
	ptr2Tree->printInorder();
	std::cout <<std::endl << "PostOrdered Print: ";
	ptr2Tree->printPostorder();

	std::cout << std::endl << "Size: ";
	ptr2Tree->Size();
	
	*/
	//std::cout << "Hello World!\n";
	//program in the things the supplement requires me to do
	//if says "declare string of ints and insert into tree, do that EXACTLY in main
}
//Preorder: self -> left -> right = 
//Inorder: left -> self -> right = ascending numeric order left to right
//Postorder: left -> right -> self =