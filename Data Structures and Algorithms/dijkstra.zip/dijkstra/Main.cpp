#include <iostream>
#include <fstream>
#include <sstream>
#include<iostream>
#include<climits>

int const arraySize = 4;
int graph[arraySize][arraySize];

char node1;
char node2;
int nodeCost;
char startNode;
//char nextNode;

int count = 0;
int x = 0;
int y = 0;
int zero = 0;
int character1 = 65;
int character2 = 65;

char E = 69;
char G = 71;
char V = 86;
char hash = 35;

/*
void arraySizeSet() {
	int* tmpArray = new int[arraySize + 1][arraySize + 1];

	if (tmpArray != NULL) {
		arraySize += 1;

		while (x < arraySize) {
			tmpArray[x][y] = graph[x][y];
		}
	}
} */

int readFile(std::string file) {
	std::ifstream File(file);
	std::string line;
	//std::istringstream iss(line);
	while (std::getline(File, line)){
		/* // origial readFile for original dijkstra code authored by me
		while(i < arraySize + 5){
			node1[i] = line.at(0); 
			node2[i] = line.at(2); 
			nodeCost[i] = line.at(4); 
			std::cout << node1[i] << " " << node2[i] << " " << nodeCost[i] - 48 << "\n";
			i++;
			if (!(iss >> node1[i] >> node2[i] >> nodeCost[i])) {
				break;
			}
		}*/
		if (line.length() == 0) {
			continue;
		}
		if (line.at(0) == hash) {
			continue;
		}/*
		 //dynamic resize
		if (line.at(0) == V){
			arraySizeSet();
		} */
		if (line.at(0) == E){
			for (int count = 0; count < 1; count++) {
				node1 = line.at(8);
				node2 = line.at(11);
				nodeCost = line.at(14) - 48;
				character1 = 65;
				for (int i = 0; i < arraySize; i++) {
					int j = 0;
					character2 = 65;
					while(j < arraySize) {
						if ((node1 == character1) && (node2 == character2)) {
							graph[x + i][y + j] = nodeCost;
							graph[x + j][y + i] = nodeCost;
						}
						character2++;
						j++;
					}
					character1++;
				}
				/*
				if ((node1 == A) && (node2 == A)) {
					graph[x][y] = 0;
				}
				else if ((node1 == A) && (node2 == B)) {
					graph[x][y + 1] = nodeCost;
				}
				else if ((node1 == A) && (node2 == C)) {
					graph[x][y + 2] = nodeCost;
				}
				else if ((node1 == A) && (node2 == D)) {
					graph[x][y + 3] = nodeCost;
				}
				else if ((node1 == A) && (node2 == E)) {
					graph[x][y + 4] = nodeCost;
				}
				else if ((node1 == B) && (node2 == A)) {
					graph[x + 1][y] = nodeCost;
				}
				else if ((node1 == B) && (node2 == B)) {
					graph[x + 1][y + 1] = 0;
				}
				else if ((node1 == B) && (node2 == C)) {
					graph[x + 1][y + 2] = nodeCost;
				}
				else if ((node1 == B) && (node2 == D)) {
					graph[x + 1][y + 3] = nodeCost;
				}
				else if ((node1 == B) && (node2 == E)) {
					graph[x + 1][y + 4] = nodeCost;
				}
				else if ((node1 == C) && (node2 == A)) {
					graph[x + 2][y] = nodeCost;
				}
				else if ((node1 == C) && (node2 == B)) {
					graph[x + 2][y + 1] = nodeCost;
				}
				else if ((node1 == C) && (node2 == C)) {
					graph[x + 2][y + 2] = 0;
				}
				else if ((node1 == C) && (node2 == D)) {
					graph[x + 2][y + 3] = nodeCost;
				}
				else if ((node1 == C) && (node2 == E)) {
					graph[x + 2][y + 4] = nodeCost;
				}
				else if ((node1 == D) && (node2 == A)) {
					graph[x + 3][y] = nodeCost;
				}
				else if ((node1 == D) && (node2 == B)) {
					graph[x + 3][y + 1] = nodeCost;
				}
				else if ((node1 == D) && (node2 == C)) {
					graph[x + 3][y + 2] = nodeCost;
				}
				else if ((node1 == D) && (node2 == D)) {
					graph[x + 3][y + 3] = 0;
				}
				else if ((node1 == D) && (node2 == E)) {
					graph[x + 3][y + 4] = nodeCost;
				}
				else if ((node1 == E) && (node2 == A)) {
					graph[x + 4][y] = nodeCost;
				}
				else if ((node1 == E) && (node2 == B)) {
					graph[x + 4][y + 1] = nodeCost;
				}
				else if ((node1 == E) && (node2 == C)) {
					graph[x + 4][y + 2] = nodeCost;
				}
				else if ((node1 == E) && (node2 == D)) {
					graph[x + 4][y + 3] = nodeCost;
				}
				else if ((node1 == E) && (node2 == E)) {
					graph[x + 4][y + 4] = 0;
				}
				else {
					graph[x][y] = 0;
				} */
			}
			count++;
		}
	}
	return 0;
}

void printer() {
	while (x < arraySize) {
		y = zero;
		while (y < arraySize) {
			std::cout << graph[x][y];
			y++;
		}
		x++;
		std::cout << "\n";
	}
}

void graphViz() {
	for (int count = 0; count < 1; count++) {
		character1 = 65;
		for (int i = 0; i < arraySize; i++) {
			int j = 0;
			character2 = 65;
			while (j < arraySize) {
				if ((node1 == character1) && (node2 == character2)) {
					std::cout << graph[x + i][y + j];
				}
				character2++;
				j++;
			}
			character1++;
		}
	}
	count++;
}


//Source: https://www.includehelp.com/cpp-tutorial/dijkstras-algorithm.aspx 
//dijkstra and minimumDist functions are the only code not 100% authored by me
int minimumDist(int weight[], bool nodeCheck[]){
	int min = INT_MAX, index;
	//int index;
	for (int i = 0; i < arraySize; i++){
		if (nodeCheck[i] == false && weight[i] <= min){
			min = weight[i];
			index = i;
		}
	}
	return index;
}

void dijkstra(int graph[arraySize][arraySize], int source){
	int weight[arraySize];
	bool nodeCheck[arraySize];
	for (int i = 0; i < arraySize; i++){
		weight[i] = INT_MAX;
		nodeCheck[i] = false;
	}
	weight[source] = 0;
	for (int c = 0; c < arraySize; c++){
		int minWeight = minimumDist(weight, nodeCheck); 
		nodeCheck[minWeight] = true;
		for (int i = 0; i < arraySize; i++) {
			if (!nodeCheck[i] && graph[minWeight][i] && weight[minWeight] != INT_MAX && weight[minWeight] + graph[minWeight][i] < weight[i]) {
				weight[i] = weight[minWeight] + graph[minWeight][i];

			}
		}
	}
	std::cout << "Vertex\t\tDistance from source" << std::endl;
	for (int i = 0; i < arraySize; i++){
			char printChar = 65 + i;
			std::cout << printChar << "\t\t" << weight[i] << std::endl;
	}
}
/* my original code for dijkstras algorithm below. Only showed original node and next node, not shortest path. only weights. 
int router(char a) {
	for (int i = 0; i < arraySize; i++) {
		if (a == node1[i]) {
			std::cout << a << "--->" << node2[i] << " " << nodeCost[i] - 48 << std::endl;
			//distance call here
		}
		else {
			continue;//std::cout << "-" << std::endl;
		}
	}
	return 0;
}

int routingTable() {
	//create routing table using node
	for (int i = 0; i < arraySize; i++) {
		if (startNode == node1[i]) {
			nextNode = node2[i];
			router(nextNode);
			for (int i = 0; i < arraySize; i++) {
				if (nextNode == node1[i]) {
					nextNode = node2[i];
					router(nextNode);
				}
			}
		}
		else {
			continue;
		}
	}
	return 0;
}

int distanceFinder() {
	//cost += cost;
	return 0;
}

int printDOT() {
	return 0;
}

int main() {
	//file input
	readFile("input.txt");

	//take input for node of interest
	std::cout << "Enter a node of interest (startng node): ";
	std::cin >> startNode;

	router(startNode);
	routingTable();
	//show shortest path from start to finish
} */
int main(){
	
	readFile("inputFile.txt");
	printer();
	std::cout << "Enter a starting node: ";
	std::cin >> startNode;
	int tmp = 0;
	tmp = startNode - 65;
	std::cout << std::endl;
	dijkstra(graph, tmp); // set source as input cin
	//graphViz();
}
