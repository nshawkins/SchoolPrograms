public class Fac{
    String name;
    String position;
    String [] publications;

    public Fac(){
        this.name = null;
        this.position = null;
        this.publications = null;
    }
    public void xFac(int n ){
        publications = new String [n];
    }
} 