public class Pub{
    String author;
    String title;
    String confName;
    String confLoc;
    int year;

    public Pub(){
        this.author = null;
        this.title = null;
        this.confName = null;
        this.confLoc = null;
        this.year = 0;
    }
} 